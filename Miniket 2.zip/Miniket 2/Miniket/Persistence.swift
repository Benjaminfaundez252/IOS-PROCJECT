import CoreData

struct PersistenceController {
    static let shared = PersistenceController()

    // Contenedor persistente
    let container: NSPersistentContainer

    init(inMemory: Bool = false) {
        container = NSPersistentContainer(name: "Miniket") // Nombre del modelo Core Data (.xcdatamodeld)
        
        if inMemory {
            // Para pruebas: almacena en memoria volátil (no guarda en disco)
            container.persistentStoreDescriptions.first?.url = URL(fileURLWithPath: "/dev/null")
        }
        
        container.loadPersistentStores { description, error in
            if let error = error {
                fatalError("Error al cargar el Core Data Store: \(error)")
            }
        }
        
        // Configura para que los contextos hagan merges automáticamente
        container.viewContext.automaticallyMergesChangesFromParent = true
    }
}
