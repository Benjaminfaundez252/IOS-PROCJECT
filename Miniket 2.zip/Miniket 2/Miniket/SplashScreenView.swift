//
//  SplashScreenView.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 11-08-25.
import SwiftUI

struct SplashScreenView: View {
    @State private var progress: CGFloat = 0.0
    @State private var tipIndex: Int = 0
    @State private var isActive: Bool = false
    
    private let tips = [
        "¡Recuerda capturar a todos tus minikets!",
        "Puedes encontrar minikets raros en lugares especiales.",
        "La barra de energía se recarga con tus caminatas.",
        "Alimenta a tu miniket para que crezca rápido.",
        "Participa en batallas para ganar recompensas."
    ]
    
    private let totalDuration: Double = 5.0
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.blue.opacity(0.8), Color.white]),
                startPoint: .top,
                endPoint: .bottom
            )
            .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 50) {
                Spacer()
                
                // Logo abstracto estilo Pokémon GO
                ZStack {
                    Circle()
                        .fill(Color.white)
                        .frame(width: 150, height: 150)
                        .shadow(radius: 10)
                    
                    Circle()
                        .stroke(Color.green, lineWidth: 6)
                        .frame(width: 120, height: 120)
                        .scaleEffect(1 + 0.05 * sin(progress * 10))
                        .animation(.easeInOut(duration: 0.3), value: progress)
                    
                    Circle()
                        .fill(Color.blue.opacity(0.5))
                        .frame(width: 60, height: 60)
                        .rotationEffect(.degrees(Double(progress) * 360))
                        .animation(.linear(duration: 0.2), value: progress)
                }
                
                // Barra de progreso
                ZStack(alignment: .leading) {
                    Capsule()
                        .frame(height: 20)
                        .foregroundColor(Color.gray.opacity(0.3))
                    
                    Capsule()
                        .frame(width: progressBarWidth(), height: 20)
                        .foregroundColor(Color.green)
                        .animation(.easeInOut(duration: 0.2), value: progress)
                }
                .padding(.horizontal, 40)
                
                // Tip de carga
                Text(tips[tipIndex])
                    .font(.subheadline)
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)
                
                Spacer()
                
                Text("Cargando Miniket...")
                    .foregroundColor(.white)
                    .fontWeight(.bold)
                    .shadow(radius: 2)
                
                Spacer().frame(height: 20)
            }
        }
        .onAppear {
            startLoading()
        }
        .fullScreenCover(isPresented: $isActive) {
            MainView()
        }
    }
    
    private func progressBarWidth() -> CGFloat {
        let screenWidth = UIScreen.main.bounds.width - 80
        return screenWidth * progress
    }
    
    private func startLoading() {
        let stepDuration = totalDuration / Double(tips.count)
        
        for i in 0..<tips.count {
            DispatchQueue.main.asyncAfter(deadline: .now() + stepDuration * Double(i)) {
                tipIndex = i
                progress = CGFloat(Double(i + 1) / Double(tips.count))
            }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + totalDuration) {
            isActive = true
        }
    }
}
