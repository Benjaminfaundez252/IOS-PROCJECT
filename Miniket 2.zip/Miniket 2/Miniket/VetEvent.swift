//
//  VetEvent.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 12-08-25.
//
import Foundation

struct VetEvent: Identifiable, Codable, Equatable {
    let id: UUID
    var title: String
    var date: Date

    var formattedDate: String {
        date.formatted(date: .abbreviated, time: .shortened)
    }

    static func sampleEvents() -> [VetEvent] {
        [
            VetEvent(id: UUID(), title: "Vacuna anual - Luna", date: Calendar.current.date(byAdding: .day, value: 3, to: Date())!),
            VetEvent(id: UUID(), title: "Control post-quirúrgico - Max", date: Calendar.current.date(byAdding: .day, value: 10, to: Date())!)
        ]
    }
}
