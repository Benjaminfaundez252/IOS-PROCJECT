//
//  PhotoSourcePicker.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 11-08-25.
//
import SwiftUI

struct PhotoSourcePicker: View {
    @Binding var image: UIImage?
    @State private var showPicker = false
    @State private var sourceType: UIImagePickerController.SourceType = .photoLibrary

    var body: some View {
        VStack(spacing: 20) {
            Button("Tomar Foto") {
                sourceType = .camera
                showPicker = true
            }
            Button("Seleccionar de la Galería") {
                sourceType = .photoLibrary
                showPicker = true
            }
            Button("Cancelar") {
                showPicker = false
            }
        }
        .sheet(isPresented: $showPicker) {
            ImagePicker(image: $image, sourceType: sourceType)
        }
    }
}
