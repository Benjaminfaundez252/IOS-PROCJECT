//
//  DeceasedPetView.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 15-08-25.
//
import SwiftUI

struct DeceasedPetView: View {
    @ObservedObject var store: PetMemoryStore
    @Binding var isPresented: Bool
    
    var body: some View {
        NavigationView {
            List(store.pets.filter { $0.isDeceased }) { pet in
                NavigationLink(destination: PetMemoryDetailView(pet: pet)) {
                    PetMemoryListRow(pet: pet)
                }
            }
            .navigationTitle("Mascotas Fallecidas")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cerrar") { isPresented = false }
                }
            }
        }
    }
}
