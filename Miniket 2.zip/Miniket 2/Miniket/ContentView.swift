import SwiftUI

struct ContentView: View {
    @StateObject private var store = PetMemoryStore()
    @State private var showingAddPet = false
    @AppStorage("isVetMode") private var isVetMode = false // Almacena el estado en UserDefaults
    @State private var showingVetMode = false

    var body: some View {
        NavigationView {
            List {
                ForEach(store.pets) { pet in
                    NavigationLink(destination: PetMemoryDetailView(pet: pet)) {
                        PetMemoryRow(pet: pet)
                    }
                }
                .onDelete { indexSet in
                    store.removePet(at: indexSet)
                }
            }
            .navigationTitle("MiniKet")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showingAddPet = true }) {
                        Label("Agregar", systemImage: "plus")
                    }
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    if isVetMode {
                        Button(action: { showingVetMode = true }) {
                            Label("Veterinario", systemImage: "stethoscope")
                        }
                    } else {
                        EmptyView()
                    }
                }
            }
            .sheet(isPresented: $showingAddPet) {
                AddPetMemoryWrapper(store: store, isPresented: $showingAddPet, isVetMode: $isVetMode)
            }
            .sheet(isPresented: $showingVetMode) {
                VetModeWrapper(store: store, isPresented: $showingVetMode, isVetMode: $isVetMode)
            }
        }
    }
}

#Preview {
    ContentView()
}
