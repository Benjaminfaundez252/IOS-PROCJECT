//
//  VetModeView.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 13-08-25.
//
import SwiftUI

struct VetModeView: View {
    @ObservedObject var store: PetMemoryStore
    @Binding var isPresented: Bool
    @Binding var isVetMode: Bool // Recibe el binding desde ContentView
    @State private var selectedPet: PetMemory?

    var body: some View {
        NavigationView {
            Form {
                Picker("Seleccionar Mascota", selection: $selectedPet) {
                    Text("Ninguna").tag(PetMemory?.none)
                    ForEach(store.pets) { pet in
                        Text(pet.name).tag(pet as PetMemory?)
                    }
                }
                if let selectedPet = selectedPet {
                    Section(header: Text("Detalles de Mascota")) {
                        Text("Nombre: \(selectedPet.name)")
                        Text("Fecha: \(selectedPet.dateFormatted)")
                        Text("Legendario: \(selectedPet.isLegendary ? "Sí" : "No")")
                        Text("Fallecido: \(selectedPet.isDeceased ? "Sí" : "No")")
                        if let species = selectedPet.species { Text("Especie: \(species)") }
                        if let audioURL = selectedPet.audioURL {
                            Text("Audio: \(audioURL.lastPathComponent)")
                        }
                        if let imageURL = selectedPet.imageURL {
                            Text("Imagen: \(imageURL.lastPathComponent)")
                        }
                        Text("Medicamentos: \(selectedPet.medicamentos.joined(separator: ", "))")
                        Text("Recetas: \(selectedPet.recetas.joined(separator: ", "))")
                    }
                }
            }
            .navigationTitle("Modo Veterinario")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cerrar") { isPresented = false }
                }
            }
        }
        .accessibilityLabel("Modo veterinario para mascotas")
    }
}
