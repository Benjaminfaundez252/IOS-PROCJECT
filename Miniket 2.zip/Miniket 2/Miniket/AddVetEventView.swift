//
//  AddVetEventView.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 12-08-25.
//
import SwiftUI

struct AddVetEventView: View {
    @Binding var events: [VetEvent]
    @State private var title = ""
    @State private var date = Date()

    var body: some View {
        NavigationView {
            Form {
                TextField("Título del evento", text: $title)
                DatePicker("Fecha", selection: $date, displayedComponents: [.date, .hourAndMinute])

                Button("Guardar") {
                    let newEvent = VetEvent(id: UUID(), title: title, date: date)
                    events.append(newEvent)
                }
            }
            .navigationTitle("Nuevo evento")
        }
    }
}
