//
//  PetMemoryDetailView.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 13-08-25.
//
import SwiftUI

struct PetMemoryDetailView: View {
    let pet: PetMemory
    var body: some View {
        VStack {
            Text("Name: \(pet.name)")
            Text("Date: \(pet.dateFormatted)")
            Text("Legendary: \(pet.isLegendary ? "Yes" : "No")")
           
            if let imageURL = pet.imageURL { Text("Image: \(imageURL.lastPathComponent)") }
            Text("Medicamentos: \(pet.medicamentos.joined(separator: ", "))")
            Text("Recetas: \(pet.recetas.joined(separator: ", "))")
        }
    }
}
