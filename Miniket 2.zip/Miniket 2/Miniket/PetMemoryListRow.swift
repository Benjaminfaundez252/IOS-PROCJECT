//
//  PetMemoryListRow.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 13-08-25.
//
import SwiftUI

struct PetMemoryListRow: View {
    let pet: PetMemory

    var body: some View {
        HStack {
            Image(systemName: pet.isLegendary ? "star.circle.fill" : "heart.circle")
                .foregroundColor(pet.isLegendary ? .yellow : .pink)
            VStack(alignment: .leading) {
                Text(pet.name)
                    .font(.headline)
                Text(pet.species ?? "Sin especie") // Corrección: Valor predeterminado
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            Spacer()
            if pet.isDeceased {
                Text("Fallecido")
                    .font(.caption)
                    .foregroundColor(.red)
                    .padding(4)
                    .background(Color.red.opacity(0.1))
                    .cornerRadius(4)
            }
        }
        .foregroundColor(pet.isDeceased ? .gray : .primary) // Gris para fallecidos
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Mascota \(pet.name), \(pet.species ?? "sin especie"), \(pet.dateFormatted), \(pet.isDeceased ? "fallecida" : "viva")")
        .accessibilityHint("Toca para ver detalles")
    }
}
