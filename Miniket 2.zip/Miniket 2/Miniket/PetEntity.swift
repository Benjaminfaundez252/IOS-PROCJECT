//
//  PetEntity.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 12-08-25.
//
import Foundation
import CoreData
import UIKit

@objc(PetEntity)
public class PetEntity: NSManagedObject {}

extension PetEntity {
    @nonobjc public class func fetchRequest() -> NSFetchRequest<PetEntity> {
        return NSFetchRequest<PetEntity>(entityName: "PetEntity")
    }

    @NSManaged public var id: UUID
    @NSManaged public var name: String
    @NSManaged public var type: String
    @NSManaged public var isLegendary: Bool
    @NSManaged public var dateCaptured: Date
    @NSManaged public var location: String?
    @NSManaged public var imagePath: String?
    @NSManaged public var audioPath: String?

    var wrappedName: String { name }
    var wrappedType: String { type }
    var wrappedDate: Date { dateCaptured }

    var locationDescription: String {
        location ?? "No location"
    }

    var imageURL: URL? {
        guard let path = imagePath else { return nil }
        return URL(fileURLWithPath: path)
    }

    var audioURL: URL? {
        guard let path = audioPath else { return nil }
        return URL(fileURLWithPath: path)
    }
}
