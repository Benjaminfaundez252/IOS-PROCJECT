//
//  SettingsView.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 11-08-25.
//
import SwiftUI

struct SettingsView: View {
    // MARK: - Estados
    @State private var notificationsEnabled = true
    @State private var darkModeEnabled = false
    @State private var vibrationEnabled = true
    @State private var soundEnabled = true
    @State private var selectedLanguage = "Español"
    @State private var username = "Entrenador Miniket"
    @State private var accentColor = Color.green
    
    let languages = ["Español", "Inglés", "Francés", "Chino"]
    let accentColors: [Color] = [.green, .blue, .orange, .red, .purple]
    
    var body: some View {
        NavigationView {
            Form {
                
                // MARK: - General
                Section(header: Text("General")) {
                    Toggle("Notificaciones", isOn: $notificationsEnabled)
                    Toggle("Modo Oscuro", isOn: $darkModeEnabled)
                    Toggle("Vibración", isOn: $vibrationEnabled)
                    Toggle("Sonido de Minikets", isOn: $soundEnabled)
                    
                    // Picker de color de acento
                    Picker("Color de la App", selection: $accentColor) {
                        ForEach(accentColors, id: \.self) { color in
                            HStack {
                                Circle()
                                    .fill(color)
                                    .frame(width: 20, height: 20)
                                Text(colorName(color))
                            }
                            .tag(color)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                }
                
                // MARK: - Idioma
                Section(header: Text("Idioma")) {
                    Picker("Selecciona un idioma", selection: $selectedLanguage) {
                        ForEach(languages, id: \.self) { lang in
                            Text(lang)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .onChange(of: selectedLanguage) { newLang in
                        applyLanguage(newLang)
                    }
                }
                
                // MARK: - Cuenta
                Section(header: Text("Cuenta")) {
                    HStack {
                        Text("Usuario")
                        Spacer()
                        TextField("Nombre de usuario", text: $username)
                            .multilineTextAlignment(.trailing)
                    }
                    
                    Button("Cerrar sesión") {
                        print("Cerrar sesión activado")
                    }
                    .foregroundColor(.red)
                    
                    Button("Restablecer datos de cuenta") {
                        resetAccount()
                    }
                    .foregroundColor(.orange)
                }
                
                // MARK: - Minikets
                Section(header: Text("Minikets")) {
                    HStack {
                        Text("Mascotas capturadas")
                        Spacer()
                        Text("12") // Vincular con tu modelo real
                    }
                    
                    Button("Restablecer progreso de Minikets") {
                        resetMinikets()
                    }
                    .foregroundColor(.orange)
                }
                
                // MARK: - Información
                Section(header: Text("Información")) {
                    HStack {
                        Text("Versión de la App")
                        Spacer()
                        Text("2.0 Beta 2")
                            .foregroundColor(.gray)
                    }
                    HStack {
                        Text("Soporte")
                        Spacer()
                        Text("soporte@miniket.app")
                            .foregroundColor(.blue)
                    }
                }
            }
            .navigationTitle("Configuración")
            .accentColor(accentColor) // Aplica el color seleccionado a la UI
        }
    }
    
    // MARK: - Funciones
    private func resetAccount() {
        username = "Entrenador Miniket"
        print("Datos de cuenta restablecidos")
    }
    
    private func resetMinikets() {
        print("Progreso de minikets restablecido")
    }
    
    private func applyLanguage(_ language: String) {
        // Aquí puedes cambiar la localización de tu app
        print("Idioma cambiado a: \(language)")
    }
    
    private func colorName(_ color: Color) -> String {
        switch color {
        case .green: return "Verde"
        case .blue: return "Azul"
        case .orange: return "Naranja"
        case .red: return "Rojo"
        case .purple: return "Morado"
        default: return "Personalizado"
        }
    }
}

// MARK: - Preview
struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
