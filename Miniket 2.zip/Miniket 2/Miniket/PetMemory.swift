//
//  PetMemory.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 13-08-25.

import Foundation

struct PetMemory: Identifiable, Codable, Hashable {
    let id: UUID
    var name: String
    var date: Date
    var isLegendary: Bool
    var audioFilename: String?
    var imageFilename: String?
    var medicamentos: [String] = []
    var recetas: [String] = []
    var isDeceased: Bool = false
    var species: String? // Propiedad para la especie (e.g., "perro", "gato"), opcional

    // MARK: - Archivos guardados
    var audioURL: URL? {
        guard let filename = audioFilename else { return nil }
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?
            .appendingPathComponent("MiniketPets")
            .appendingPathComponent(filename)
    }

    var imageURL: URL? {
        guard let filename = imageFilename else { return nil }
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?
            .appendingPathComponent("MiniketPets")
            .appendingPathComponent(filename)
    }

    var dateFormatted: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }

    init(
        id: UUID = UUID(),
        name: String,
        date: Date = Date(),
        isLegendary: Bool = false,
        audioFilename: String? = nil,
        imageFilename: String? = nil,
        medicamentos: [String] = [],
        recetas: [String] = [],
        isDeceased: Bool = false,
        species: String? = nil // Inicialización de species
    ) {
        self.id = id
        self.name = name
        self.date = date
        self.isLegendary = isLegendary
        self.audioFilename = audioFilename
        self.imageFilename = imageFilename
        self.medicamentos = medicamentos
        self.recetas = recetas
        self.isDeceased = isDeceased
        self.species = species
    }
}
