//
//  VetModeWrapper.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 13-08-25.
//
import SwiftUI

struct VetModeWrapper: View {
    @ObservedObject var store: PetMemoryStore
    @Binding var isPresented: Bool
    @Binding var isVetMode: Bool // Añadir este binding

    var body: some View {
        VetModeView(store: store, isPresented: $isPresented, isVetMode: $isVetMode) // Pasar el binding
    }
}
