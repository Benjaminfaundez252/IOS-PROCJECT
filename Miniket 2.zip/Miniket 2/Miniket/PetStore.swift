//
//  PetStore.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 12-08-25.
//
import SwiftUI

class PetMemoryStore: ObservableObject {
    @Published var pets: [PetMemory] = []

    private let petsFileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.appendingPathComponent("pets.json")

    init() {
        loadPets()
    }

    func addPet(name: String, date: Date = Date(), isLegendary: Bool = false, audioFilename: String? = nil, imageFilename: String? = nil, medicamentos: [String] = [], recetas: [String] = [], isDeceased: Bool = false, species: String? = nil) { // Añadido species
        let newPet = PetMemory(
            id: UUID(),
            name: name,
            date: date,
            isLegendary: isLegendary,
            audioFilename: audioFilename,
            imageFilename: imageFilename,
            medicamentos: medicamentos,
            recetas: recetas,
            isDeceased: isDeceased,
            species: species
        )
        pets.append(newPet)
        savePets()
    }

    func removePet(at offsets: IndexSet) {
        pets.remove(atOffsets: offsets)
        savePets()
    }

    private func savePets() {
        do {
            let data = try JSONEncoder().encode(pets)
            try data.write(to: petsFileURL)
        } catch {
            print("Error saving pets: \(error)")
        }
    }

    private func loadPets() {
        do {
            let data = try Data(contentsOf: petsFileURL)
            pets = try JSONDecoder().decode([PetMemory].self, from: data)
        } catch {
            print("Error loading pets: \(error)")
            pets = []
        }
    }
}
