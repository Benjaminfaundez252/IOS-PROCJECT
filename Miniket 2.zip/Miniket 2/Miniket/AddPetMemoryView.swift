//
//  AddPetMemoryView.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 13-08-25.
//
import SwiftUI

struct AddPetMemoryView: View {
    @ObservedObject var store: PetMemoryStore
    @Binding var isPresented: Bool
    @Binding var isVetMode: Bool
    
    // Datos del formulario
    @State private var name: String = ""
    @State private var date: Date = Date()
    @State private var isLegendary: Bool = false
    @State private var audioFilename: String? = nil
    @State private var imageFilename: String? = nil
    @State private var medicamentosText: String = ""
    @State private var recetasText: String = ""
    @State private var isDeceased: Bool = false
    @State private var species: String? = nil
    @State private var notes: String = ""
    @State private var reminderDate: Date? = nil
    
    // Mejoras UX
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        NavigationView {
            Form {
                // INFORMACIÓN BÁSICA
                Section(header: Text("Información Básica")) {
                    TextField("Nombre", text: $name)
                        .accessibilityLabel("Nombre de la mascota")
                        .autocorrectionDisabled(true)
                        .textInputAutocapitalization(.words)

                    DatePicker("Fecha", selection: $date, displayedComponents: .date)

                    Toggle("Legendario", isOn: $isLegendary)
                    Toggle("Fallecido", isOn: $isDeceased)

                    TextField("Audio Filename", text: Binding(
                        get: { audioFilename ?? "" },
                        set: { audioFilename = $0.isEmpty ? nil : $0 }
                    ))
                    .autocorrectionDisabled(true)

                    TextField("Image Filename", text: Binding(
                        get: { imageFilename ?? "" },
                        set: { imageFilename = $0.isEmpty ? nil : $0 }
                    ))
                    .autocorrectionDisabled(true)

                    TextField("Especie (e.g., perro, gato)", text: Binding(
                        get: { species ?? "" },
                        set: { species = $0.isEmpty ? nil : $0 }
                    ))
                    .autocorrectionDisabled(true)
                }
                
                // TRATAMIENTOS
                Section(header: Text("Tratamientos")) {
                    TextField("Medicamentos (separados por coma)", text: $medicamentosText)
                        .autocorrectionDisabled(true)

                    TextField("Recetas (separados por coma)", text: $recetasText)
                        .autocorrectionDisabled(true)

                    if isVetMode {
                        DatePicker("Recordatorio (opcional)", selection: Binding(
                            get: { reminderDate ?? Date() },
                            set: { reminderDate = $0 }
                        ), displayedComponents: [.date, .hourAndMinute])
                    }
                }
                
                // NOTAS
                Section(header: Text("Notas")) {
                    TextEditor(text: $notes)
                        .frame(height: 100)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.gray, lineWidth: 1)
                        )
                        .accessibilityLabel("Notas para la mascota")
                }
            }
            .navigationTitle("Agregar Mascota")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") {
                        isPresented = false
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") {
                        if validateFields() {
                            savePet()
                            isPresented = false
                        } else {
                            showAlert = true
                        }
                    }
                    .disabled(name.isEmpty) // Bloquea si no hay nombre
                }
            }
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Campos incompletos"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
        .accessibilityLabel("Formulario para agregar o editar mascota")
    }
    
    // MARK: - Validación
    private func validateFields() -> Bool {
        if name.trimmingCharacters(in: .whitespaces).isEmpty {
            alertMessage = "Por favor ingresa un nombre para la mascota."
            return false
        }
        return true
    }
    
    // MARK: - Guardar Mascota
    private func savePet() {
        let medicamentos = medicamentosText.split(separator: ",").map { String($0.trimmingCharacters(in: .whitespaces)) }
        let recetas = recetasText.split(separator: ",").map { String($0.trimmingCharacters(in: .whitespaces)) }

        store.addPet(
            name: name,
            date: date,
            isLegendary: isLegendary,
            audioFilename: audioFilename,
            imageFilename: imageFilename,
            medicamentos: medicamentos,
            recetas: recetas,
            isDeceased: isDeceased,
            species: species
        )

        if isVetMode, let reminderDate = reminderDate {
            ReminderManager.shared.scheduleReminder(for: medicamentos, at: reminderDate)
        }
    }
}
