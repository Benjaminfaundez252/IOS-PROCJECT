//
//  PetMemoryRow.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 13-08-25.
//
import SwiftUI

struct PetMemoryRow: View {
    let pet: PetMemory

    var body: some View {
        HStack {
            Text(pet.name)
            Spacer()
            if pet.isLegendary {
                Image(systemName: "star.fill")
                    .foregroundColor(.yellow)
            }
        }
    }
}
