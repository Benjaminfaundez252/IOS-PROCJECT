//
//  ReminderManager.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 15-08-25.
//
import UserNotifications

class ReminderManager {
    static let shared = ReminderManager()
    
    func scheduleReminder(for medicamentos: [String], at date: Date) {
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .sound]) { granted, _ in
            if granted {
                let content = UNMutableNotificationContent()
                content.title = "Recordatorio de Medicamentos"
                content.body = "Tiempo para \(medicamentos.joined(separator: ", "))"
                content.sound = .default
                let trigger = UNCalendarNotificationTrigger(dateMatching: Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: date), repeats: false)
                let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
                center.add(request)
            }
        }
    }
}
