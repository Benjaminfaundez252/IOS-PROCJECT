//
//  MainView.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 11-08-25.
//
import SwiftUI

// MARK: - Modelo Miniket
struct Miniket: Identifiable {
    let id = UUID()
    var name: String
    var level: Int
    var energy: Int
    var isSick: Bool = false
    var prescriptions: [String] = []
    var isDeceased: Bool = false
    var dedication: String? = nil
    var furTone: String? = nil
    var eyeColor: String? = nil
    var skinTone: String? = nil
    var uiImage: UIImage? = nil
}

// MARK: - MainView
struct MainView: View {
    @State private var selectedTab = 0
    @State private var minikets: [Miniket] = []
    @State private var showAddSheet = false
    
    var body: some View {
        TabView(selection: $selectedTab) {
            
            // ---------------- Mascotas ----------------
            NavigationView {
                VStack {
                    if minikets.isEmpty {
                        Text("No tienes mascotas aún")
                            .foregroundColor(.gray)
                            .padding()
                    } else {
                        ScrollView {
                            LazyVStack(spacing: 12) {
                                ForEach(minikets.indices, id: \.self) { index in
                                    miniketCard(minikets[index])
                                }
                                .onDelete { indexSet in
                                    minikets.remove(atOffsets: indexSet)
                                }
                            }
                            .padding()
                        }
                    }
                    
                    Button(action: { showAddSheet.toggle() }) {
                        Label("Agregar Mascota", systemImage: "plus.circle.fill")
                            .font(.title2)
                            .padding()
                    }
                    .buttonStyle(.borderedProminent)
                    .sheet(isPresented: $showAddSheet) {
                        AddMiniketView(minikets: $minikets)
                    }
                }
                .navigationTitle("Mascotas")
            }
            .tabItem { Label("Mascotas", systemImage: "pawprint.fill") }
            .tag(0)
            
            // ---------------- Veterinario ----------------
            NavigationView {
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(minikets.filter { $0.isSick }) { m in
                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    Text(m.name)
                                        .font(.headline)
                                    Spacer()
                                    Text("Nivel \(m.level)")
                                        .foregroundColor(.gray)
                                }
                                Text("Recetas: \(m.prescriptions.joined(separator: ", "))")
                                    .foregroundColor(.blue)
                                Button("Agregar receta") {
                                    // acción agregar receta
                                }
                                .buttonStyle(.borderedProminent)
                            }
                            .padding()
                            .background(Color.red.opacity(0.2))
                            .cornerRadius(12)
                        }
                    }
                    .padding()
                }
                .navigationTitle("Veterinario")
            }
            .tabItem { Label("Veterinario", systemImage: "stethoscope") }
            .tag(1)
            
            // ---------------- Recordatorio ----------------
            NavigationView {
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(minikets.filter { $0.isDeceased }) { m in
                            VStack(alignment: .leading, spacing: 8) {
                                if let img = m.uiImage {
                                    Image(uiImage: img)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: 150)
                                        .cornerRadius(12)
                                }
                                Text(m.name)
                                    .font(.headline)
                                if let dedication = m.dedication {
                                    Text("Dedicatoria: \(dedication)")
                                }
                                HStack {
                                    if let f = m.furTone { Text("Pelaje: \(f)") }
                                    if let eyes = m.eyeColor { Text("Ojos: \(eyes)") }
                                    if let skin = m.skinTone { Text("Tez: \(skin)") }
                                }
                                .foregroundColor(.gray)
                            }
                            .padding()
                            .background(Color.gray.opacity(0.2))
                            .cornerRadius(12)
                        }
                    }
                    .padding()
                }
                .navigationTitle("Recordatorio")
            }
            .tabItem { Label("Recordatorio", systemImage: "heart.fill") }
            .tag(2)
            
            // ---------------- Historial ----------------
            NavigationView {
                List {
                    ForEach(minikets) { m in
                        Section(header: Text(m.name)) {
                            if m.prescriptions.isEmpty {
                                Text("Sin recetas").foregroundColor(.gray)
                            } else {
                                ForEach(m.prescriptions, id: \.self) { rec in
                                    Text(rec)
                                }
                            }
                        }
                    }
                }
                .listStyle(.insetGrouped)
                .navigationTitle("Historial")
            }
            .tabItem { Label("Historial", systemImage: "book.fill") }
            .tag(3)
            
            // ---------------- Configuración ----------------
            SettingsView()
                .tabItem { Label("Configuración", systemImage: "gearshape.fill") }
                .tag(4)
        }
        .accentColor(.green)
    }
    
    // MARK: - Card de mascota
    private func miniketCard(_ m: Miniket) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            if let uiImg = m.uiImage {
                Image(uiImage: uiImg)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 120)
                    .clipped()
                    .cornerRadius(8)
            }
            HStack {
                Text(m.name).font(.headline)
                Spacer()
                Text("Nivel \(m.level)").foregroundColor(.gray)
            }
            ZStack(alignment: .leading) {
                Capsule().frame(height: 12).foregroundColor(Color.gray.opacity(0.3))
                Capsule()
                    .frame(width: CGFloat(m.energy) * 2, height: 12)
                    .foregroundColor(m.isSick ? .red : .green)
                    .animation(.easeInOut, value: m.energy)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(radius: 4)
    }
}

// MARK: - Agregar Miniket
struct AddMiniketView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var minikets: [Miniket]
    
    @State private var name = ""
    @State private var level = 1
    @State private var energy = 100
    @State private var furTone = ""
    @State private var eyeColor = ""
    @State private var skinTone = ""
    @State private var dedication = ""
    @State private var isDeceased = false
    @State private var selectedImage: UIImage? = nil
    @State private var showPhotoPicker = false
    
    var body: some View {
        NavigationView {
            Form {
                Section("Información") {
                    TextField("Nombre", text: $name)
                    Stepper("Nivel: \(level)", value: $level, in: 1...100)
                    Stepper("Energía: \(energy)", value: $energy, in: 0...100)
                }
                
                Section("Características") {
                    TextField("Pelaje", text: $furTone)
                    TextField("Ojos", text: $eyeColor)
                    TextField("Tez", text: $skinTone)
                }
                
                Section("Dedicación / Fallecido") {
                    TextField("Dedicatoria", text: $dedication)
                    Toggle("Fallecido", isOn: $isDeceased)
                }
                
                Section("Imagen") {
                    if let img = selectedImage {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 150)
                            .cornerRadius(12)
                    }
                    Button("Seleccionar Foto") {
                        showPhotoPicker = true
                    }
                }
                
                Section {
                    Button("Agregar Mascota") {
                        let newMiniket = Miniket(
                            name: name,
                            level: level,
                            energy: energy,
                            isDeceased: isDeceased,
                            dedication: dedication.isEmpty ? nil : dedication,
                            furTone: furTone.isEmpty ? nil : furTone,
                            eyeColor: eyeColor.isEmpty ? nil : eyeColor,
                            skinTone: skinTone.isEmpty ? nil : skinTone,
                            uiImage: selectedImage
                        )
                        minikets.append(newMiniket)
                        dismiss()
                    }
                    .disabled(name.isEmpty)
                }
            }
            .navigationTitle("Agregar Mascota")
            .sheet(isPresented: $showPhotoPicker) {
                PhotoSourcePicker(image: $selectedImage)
            }
        }
    }
}
