//
//  AddPetMemoryWrapper.swift
//  Miniket
//
//  Created by Benjamin Cristobal Faundez Martinez on 13-08-25.
//
import SwiftUI

struct AddPetMemoryWrapper: View {
    @ObservedObject var store: PetMemoryStore
    @Binding var isPresented: Bool
    @Binding var isVetMode: Bool // Binding para modo veterinario

    var body: some View {
        AddPetMemoryView(store: store, isPresented: $isPresented, isVetMode: $isVetMode) // Pasar bindings
    }
}
